//
// Copyright � 2000-2003 Microsoft Corporation.  All rights reserved.
//
//
// This source code is licensed under Microsoft Shared Source License
// for the Visual Studio .NET Academic Tools Source Licensing Program
// For a copy of the license, see http://www.msdnaa.net/assignmentmanager/sourcelicense/
//
//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by AddinResources.rc
//
#define IDS_AMStUDENTCLIENTFRIENDLY     101
#define IDS_AMSTUDENTCLIENTFRIENDLY     101
#define IDS_AMStUDENTCLIENTFRIENDLY     101
#define IDS_AMSTUDENTCLIENTDESC         102
#define IDS_AMFACULTYCLIENTFRIENDLY     103
#define IDS_AMFACULTYCLIENTDESC         104
#define IDS_AMTOOLSOPTIONSHEADER        105
#define IDS_AMTOOLSOPTIONSCODEEXTRACT   106

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
